# Chronos Med — MBBS Study OS

A glossy-blue, responsive, installable study planner starter for medical students. It is a static website and can be deployed directly to GitHub Pages.

## Features in this starter

- Responsive dark blue glass-inspired interface, with light theme toggle.
- 19 editable starter MBBS subjects and custom subjects.
- Topic and subtopic management with completion tracking.
- Daily timeline with colored sessions, add/edit/delete, drag to move, and resize handles.
- Daily/previous/next date planning, simple reusable day template.
- Focus timer with focus/break/stopwatch modes, session linking, pause/resume, and persisted elapsed time.
- Revision queue with Again / Good / Easy review outcomes.
- Focus analytics, subject progress, daily goal, and weekly focus chart.
- JSON backup export/import.
- PWA manifest and service worker for Home Screen installation and basic offline shell caching.
- Browser-local persistence via localStorage.

## Run locally

Because the service worker requires HTTP(S), use a local server rather than opening `index.html` directly.

```bash
python3 -m http.server 8000
```

Open `http://localhost:8000` in your browser.

## Deploy to GitHub Pages

1. Create a new GitHub repository, e.g. `chronos-med`.
2. Upload the contents of this folder to the repository root (so `index.html` is at the root).
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. Open the Pages URL shown in Settings → Pages.

GitHub Pages serves HTTPS, which is needed for PWA installation and service workers.

## Add to iPhone or iPad Home Screen

1. Open the deployed GitHub Pages URL in **Safari**.
2. Tap **Share**.
3. Choose **Add to Home Screen**.
4. Keep the name as `Chronos Med` and tap **Add**.
5. Launch it from the new Home Screen icon.

If the option is not visible, scroll the Share sheet. PWA support varies by browser and OS version; Safari is the recommended route on iOS/iPadOS.

## Data and privacy

This version stores data in the current browser/device using localStorage. It does not include accounts, server-side storage, or cross-device synchronization. Use **Settings → Export JSON** to back up your data regularly. Clearing browser website data may remove the local planner. The service worker caches the app shell but does not synchronize your planner between devices.

## Important implementation notes

- This is a useful first working version, not a fully audited production service.
- Session timer records are associated with the current date at the time a session is finished.
- Timeline blocks support pointer drag/resize and basic snapping; keyboard alternatives, collision-aware auto-scheduling, recurring events, and a complete week/month calendar are future enhancements.
- The service worker provides basic shell caching. External Google Fonts require internet access.
- Do not put confidential patient information in this personal study planner.

## Next recommended upgrades

1. Add automated tests for scheduling, timezone boundaries, and timer behavior.
2. Add robust touch-specific drag/resize interactions and keyboard alternatives.
3. Add secure authentication and database-backed sync only if multi-device use is required.
4. Add a richer calendar, exam plans, and configurable spaced repetition.
